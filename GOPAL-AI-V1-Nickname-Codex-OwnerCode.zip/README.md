# GOPAL AI V1 — Android

Project Android dengan GitHub Actions untuk build APK langsung dari GitHub.

## Build APK dari HP

1. Buat repository baru di GitHub.
2. Upload seluruh isi project ini.
3. Buka tab **Actions**.
4. Pilih **Build GOPAL AI APK**.
5. Tekan **Run workflow**.
6. Tunggu sampai proses selesai.
7. Buka hasil workflow dan cari **Artifacts**.
8. Download `GOPAL-AI-V1-debug`.
9. Ekstrak ZIP tersebut dan install `app-debug.apk`.

Workflow juga otomatis berjalan ketika ada push ke branch `main`.

## Isi V1

- Jetpack Compose UI
- Chat interface
- SpeechRecognizer
- Android Text-to-Speech
- LlamaEngine sebagai titik integrasi llama.cpp
- Folder model/voice

Model GGUF dan binary native llama.cpp belum dibundel.


## GOPAL AI V1 - Nickname + WhatsApp + Limits

This version does not use Google/Firebase login.

First launch requires a local profile:
- Nickname
- WhatsApp number

Default non-owner limits:
- Daily: 20 requests
- Cooldown: 5 seconds
- Limit can be enabled/disabled by the owner.

Owner configuration is in:
`app/src/main/java/com/gopal/ai/AccountManager.kt`

Change:
`OWNER_NICKNAME`
`OWNER_WHATSAPP`

before distributing the APK. This local profile system is not a secure server-side authentication system. Usage and settings are stored on the device, so they are not synchronized across multiple devices.


## GOPAL AI modes
The app includes four response modes: General, Scripting, White Hacking, and Codex.
White Hacking mode is intended for authorized security testing, CTF/labs, defensive engineering, and remediation; it does not instruct users to steal credentials, deploy malware, evade detection, or defeat real-world protections without authorization.

Note: LlamaEngine remains the integration point for the actual local GGUF/llama.cpp model. The UI and prompt profiles are ready, but a GGUF model and native llama.cpp JNI integration are still required for real local inference.


## Akses akun
- User biasa mendapatkan nickname acak seperti `GOPAL-AB12CD`.
- Owner masuk memakai satu kode owner yang dapat diubah di `OwnerConfig.OWNER_CODE`.
- Sistem akun ini lokal di perangkat dan bukan autentikasi server.
