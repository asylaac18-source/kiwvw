package com.gopal.ai

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random

/**
 * Local profile + usage controller.
 *
 * Regular users receive an automatically generated nickname.
 * Owner access uses one configurable owner code.
 * This is local-device access control, not secure server authentication.
 */
object OwnerConfig {
    // Change this before distributing the APK if you want a different owner code.
    const val OWNER_CODE = "GOPAL-OWNER-7264"
    const val DEFAULT_DAILY_LIMIT = 20
    const val DEFAULT_COOLDOWN_SECONDS = 5
}

object NicknameGenerator {
    private const val PREFIX = "GOPAL"

    fun generate(): String {
        val code = buildString {
            repeat(6) {
                append("ABCDEFGHJKLMNPQRSTUVWXYZ23456789".random())
            }
        }
        return "$PREFIX-$code"
    }
}

class AccountManager(context: Context) {
    private val prefs = context.getSharedPreferences("gopal_account", Context.MODE_PRIVATE)

    val nickname: String
        get() = prefs.getString("nickname", "") ?: ""

    fun isLoggedIn(): Boolean = nickname.isNotBlank()

    /** Create a regular account with a random nickname. */
    fun loginAsUser(): String {
        val existing = nickname
        if (existing.isNotBlank()) return existing

        val generated = NicknameGenerator.generate()
        prefs.edit()
            .putString("nickname", generated)
            .putBoolean("owner", false)
            .apply()
        resetIfNewDay()
        return generated
    }

    /** Unlock owner mode with the single owner code. */
    fun loginAsOwner(code: String): Boolean {
        if (!code.trim().equals(OwnerConfig.OWNER_CODE, ignoreCase = true)) return false

        val ownerName = "PALLZYY"
        prefs.edit()
            .putString("nickname", ownerName)
            .putBoolean("owner", true)
            .apply()
        resetIfNewDay()
        return true
    }

    fun logout() {
        prefs.edit().clear().apply()
    }

    fun isOwner(): Boolean = prefs.getBoolean("owner", false)

    fun dailyLimit() = prefs.getInt("daily_limit", OwnerConfig.DEFAULT_DAILY_LIMIT)

    fun cooldownSeconds() =
        prefs.getInt("cooldown_seconds", OwnerConfig.DEFAULT_COOLDOWN_SECONDS)

    fun limitEnabled() = prefs.getBoolean("limit_enabled", true)

    fun saveSettings(limit: Int, cooldown: Int, enabled: Boolean) {
        prefs.edit()
            .putInt("daily_limit", limit)
            .putInt("cooldown_seconds", cooldown)
            .putBoolean("limit_enabled", enabled)
            .apply()
    }

    fun remainingToday(): Int {
        resetIfNewDay()
        return (dailyLimit() - prefs.getInt("requests_today", 0)).coerceAtLeast(0)
    }

    fun canSend(): Pair<Boolean, String> {
        if (isOwner() || !limitEnabled()) return true to ""
        resetIfNewDay()

        val used = prefs.getInt("requests_today", 0)
        if (used >= dailyLimit()) {
            return false to "Limit harian kamu sudah habis. Coba lagi besok."
        }

        val last = prefs.getLong("last_request_ms", 0L)
        val wait = cooldownSeconds() * 1000L - (System.currentTimeMillis() - last)
        if (wait > 0) {
            val sec = ((wait + 999) / 1000).coerceAtLeast(1)
            return false to "Tunggu ${sec} detik sebelum mengirim pesan lagi."
        }

        return true to ""
    }

    fun recordRequest() {
        if (isOwner() || !limitEnabled()) return
        resetIfNewDay()
        prefs.edit()
            .putInt("requests_today", prefs.getInt("requests_today", 0) + 1)
            .putLong("last_request_ms", System.currentTimeMillis())
            .apply()
    }

    private fun resetIfNewDay() {
        val today = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        if (prefs.getString("usage_date", "") != today) {
            prefs.edit()
                .putString("usage_date", today)
                .putInt("requests_today", 0)
                .putLong("last_request_ms", 0L)
                .apply()
        }
    }
}
