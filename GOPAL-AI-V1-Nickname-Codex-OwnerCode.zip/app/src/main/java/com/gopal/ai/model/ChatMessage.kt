package com.gopal.ai.model

data class ChatMessage(
    val text: String,
    val fromUser: Boolean
)
