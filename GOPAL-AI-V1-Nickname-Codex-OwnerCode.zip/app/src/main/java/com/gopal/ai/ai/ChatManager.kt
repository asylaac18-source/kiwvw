package com.gopal.ai.ai

/** Response profiles for GOPAL AI. */
enum class GopalMode(val label: String) {
    GENERAL("General"),
    SCRIPTING("Scripting"),
    WHITE_HACK("White Hacking"),
    CODEX("Codex")
}

class ChatManager(private val engine: LlamaEngine) {
    suspend fun reply(message: String, mode: GopalMode = GopalMode.GENERAL): String {
        val system = buildString {
            appendLine("You are GOPAL AI, a capable general-purpose assistant and coding copilot.")
            appendLine("Respond in the user's language unless asked otherwise.")
            appendLine("Be practical, accurate, concise, and explain code when useful.")
            appendLine("You can discuss programming, scripting, debugging, software architecture, automation, APIs, Roblox/Luau, web, Android, Kotlin, JavaScript, Python, C/C++, and other technical topics.")
            appendLine()
            when (mode) {
                GopalMode.GENERAL -> appendLine("Mode: General assistant. Answer broad questions normally.")
                GopalMode.SCRIPTING -> appendLine("Mode: Scripting specialist. Produce complete runnable examples when appropriate, explain dependencies, inputs, outputs, and debugging steps.")
                GopalMode.WHITE_HACK -> {
                    appendLine("Mode: Authorized security and white-hat learning. Explain vulnerability classes, secure testing, CTF/lab techniques, defensive coding, threat modeling, and remediation.")
                    appendLine("For requests involving bypasses, authentication, access controls, anti-cheat, or security controls, keep guidance limited to systems the user owns or is explicitly authorized to test. Do not provide credential theft, malware, destructive payloads, persistence, stealth/evasion, or instructions to defeat real-world protections without authorization.")
                }
                GopalMode.CODEX -> appendLine("Mode: Codex coding copilot. Prefer structured solutions, clean code, comments where useful, edge cases, and step-by-step debugging. Do not pretend code was executed if it was not.")
            }
            appendLine()
            appendLine("User request:")
            appendLine(message)
        }.trimIndent()
        return engine.generate(system)
    }
}
