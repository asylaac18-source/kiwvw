package com.gopal.ai

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.gopal.ai.ai.ChatManager
import com.gopal.ai.ai.LlamaEngine
import com.gopal.ai.ai.GopalMode
import com.gopal.ai.model.ChatMessage
import com.gopal.ai.voice.SpeechRecognizerManager
import com.gopal.ai.voice.TTSManager
import kotlinx.coroutines.launch

private val Bg = Color(0xFF09070D)
private val Panel = Color(0xFF14101C)
private val Purple = Color(0xFF8B5CF6)
private val TextMain = Color(0xFFF5F3FF)
private val Muted = Color(0xFFA9A2B7)

class MainActivity : ComponentActivity() {
    private lateinit var tts: TTSManager
    private lateinit var speech: SpeechRecognizerManager
    private lateinit var account: AccountManager

    private val micPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TTSManager(this)
        account = AccountManager(this)

        setContent {
            val scope = rememberCoroutineScope()
            val engine = remember { LlamaEngine() }
            val chat = remember { ChatManager(engine) }

            var loggedIn by remember { mutableStateOf(account.isLoggedIn()) }
            var showOwner by remember { mutableStateOf(false) }

            if (!loggedIn) {
                LoginScreen(
                    onUserLogin = {
                        account.loginAsUser()
                        loggedIn = true
                    },
                    onOwnerLogin = { code ->
                        if (account.loginAsOwner(code)) {
                            loggedIn = true
                            true
                        } else false
                    }
                )
            } else if (showOwner && account.isOwner()) {
                OwnerSettingsScreen(
                    account = account,
                    onBack = { showOwner = false }
                )
            } else {
                ChatScreen(
                    account = account,
                    chat = chat,
                    tts = tts,
                    onOwnerSettings = { showOwner = true },
                    onLogout = {
                        account.logout()
                        loggedIn = false
                    },
                    requestMic = {
                        if (ContextCompat.checkSelfPermission(
                                this, Manifest.permission.RECORD_AUDIO
                            ) != PackageManager.PERMISSION_GRANTED
                        ) micPermission.launch(Manifest.permission.RECORD_AUDIO)
                        else speech.start()
                    },
                    onSpeechReady = { inputSetter, listeningSetter ->
                        speech = SpeechRecognizerManager(
                            this,
                            onResult = inputSetter,
                            onState = listeningSetter
                        )
                    }
                )
            }
        }
    }

    override fun onDestroy() {
        if (::speech.isInitialized) speech.destroy()
        if (::tts.isInitialized) tts.shutdown()
        super.onDestroy()
    }
}

@Composable
private fun LoginScreen(
    onUserLogin: () -> Unit,
    onOwnerLogin: (String) -> Boolean
) {
    var ownerCode by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }

    Column(
        Modifier.fillMaxSize().background(Bg).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("GOPAL AI", color = TextMain, fontSize = 32.sp, fontWeight = FontWeight.Bold)
        Text("Buat nickname acak untuk mulai", color = Purple, fontSize = 13.sp)
        Spacer(Modifier.height(28.dp))

        Button(
            onClick = onUserLogin,
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = Purple)
        ) { Text("MASUK SEBAGAI USER") }

        Spacer(Modifier.height(24.dp))
        HorizontalDivider(color = Color(0xFF393244))
        Spacer(Modifier.height(20.dp))

        Text("OWNER", color = TextMain, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(
            value = ownerCode,
            onValueChange = { ownerCode = it },
            label = { Text("Kode Owner") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        if (error.isNotEmpty()) {
            Spacer(Modifier.height(8.dp))
            Text(error, color = Color(0xFFFF6B7A), fontSize = 12.sp)
        }
        Spacer(Modifier.height(12.dp))
        OutlinedButton(
            onClick = {
                if (!onOwnerLogin(ownerCode.trim())) {
                    error = "Kode owner salah."
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text("MASUK OWNER") }

        Spacer(Modifier.height(16.dp))
        Text(
            "User mendapatkan nickname GOPAL acak. Tidak perlu nomor WhatsApp.",
            color = Muted, fontSize = 11.sp
        )
    }
}

@Composable
private fun ChatScreen(
    account: AccountManager,
    chat: ChatManager,
    tts: TTSManager,
    onOwnerSettings: () -> Unit,
    onLogout: () -> Unit,
    requestMic: () -> Unit,
    onSpeechReady: (( (String) -> Unit, (Boolean) -> Unit) -> Unit)
) {
    var input by remember { mutableStateOf("") }
    var listening by remember { mutableStateOf(false) }
    var mode by remember { mutableStateOf(GopalMode.GENERAL) }
    val messages = remember { mutableStateListOf(
        ChatMessage("Halo ${account.nickname}! Aku GOPAL AI.", false)
    ) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        onSpeechReady({ input = it }, { listening = it })
    }

    Column(Modifier.fillMaxSize().background(Bg).padding(14.dp)) {
        Row(
            Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text("GOPAL AI", color = TextMain, fontSize = 27.sp, fontWeight = FontWeight.Bold)
                Text(
                    if (account.isOwner()) "OWNER • ${account.nickname}" else
                        "${account.nickname} • ${account.remainingToday()} chat tersisa",
                    color = Purple, fontSize = 11.sp
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                if (account.isOwner()) {
                    TextButton(onClick = onOwnerSettings) { Text("OWNER") }
                }
                TextButton(onClick = onLogout) { Text("KELUAR") }
            }
        }

        LazyColumn(
            Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(vertical = 12.dp)
        ) { items(messages) { MessageBubble(it) } }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("MODE", color = Muted, fontSize = 10.sp)
            var expanded by remember { mutableStateOf(false) }
            Box {
                TextButton(onClick = { expanded = true }) {
                    Text(mode.label, color = Purple)
                }
                DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                    GopalMode.values().forEach { option ->
                        DropdownMenuItem(
                            text = { Text(option.label) },
                            onClick = { mode = option; expanded = false }
                        )
                    }
                }
            }
            Text(
                when (mode) {
                    GopalMode.GENERAL -> "Tanya apa saja"
                    GopalMode.SCRIPTING -> "Scripting & debugging"
                    GopalMode.WHITE_HACK -> "Security berizin"
                    GopalMode.CODEX -> "Coding copilot"
                },
                color = Muted, fontSize = 10.sp
            )
        }

        Row(
            verticalAlignment = Alignment.Bottom,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = input, onValueChange = { input = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Tulis sesuatu...", color = Muted) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Purple, unfocusedBorderColor = Color(0xFF393244),
                    focusedTextColor = TextMain, unfocusedTextColor = TextMain, cursorColor = Purple
                ), shape = RoundedCornerShape(18.dp)
            )
            Button(
                onClick = requestMic,
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (listening) Color(0xFFB4234D) else Panel
                ), contentPadding = PaddingValues(14.dp)
            ) { Text("🎙") }
            Button(
                onClick = {
                    val prompt = input.trim()
                    if (prompt.isEmpty()) return@Button
                    val allowed = account.canSend()
                    if (!allowed.first) {
                        messages += ChatMessage(allowed.second, false)
                        return@Button
                    }
                    account.recordRequest()
                    input = ""
                    messages += ChatMessage(prompt, true)
                    scope.launch {
                        val answer = chat.reply(prompt, mode)
                        messages += ChatMessage(answer, false)
                        tts.speak(answer)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = Purple),
                contentPadding = PaddingValues(14.dp)
            ) { Text("➤", fontSize = 20.sp) }
        }
    }
}

@Composable
private fun OwnerSettingsScreen(account: AccountManager, onBack: () -> Unit) {
    var daily by remember { mutableIntStateOf(account.dailyLimit()) }
    var cooldown by remember { mutableIntStateOf(account.cooldownSeconds()) }
    var enabled by remember { mutableStateOf(account.limitEnabled()) }

    Column(Modifier.fillMaxSize().background(Bg).padding(20.dp)) {
        Text("OWNER SETTINGS", color = TextMain, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Text("Atur batas penggunaan user", color = Purple, fontSize = 12.sp)
        Spacer(Modifier.height(24.dp))

        SettingNumber("Limit per hari", daily) { daily = it.coerceIn(1, 100000) }
        SettingNumber("Cooldown (detik)", cooldown) { cooldown = it.coerceIn(0, 3600) }

        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("Aktifkan limit user", color = TextMain, modifier = Modifier.weight(1f))
            Switch(checked = enabled, onCheckedChange = { enabled = it })
        }

        Spacer(Modifier.height(20.dp))
        Button(
            onClick = {
                account.saveSettings(daily, cooldown, enabled)
                onBack()
            },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = Purple)
        ) { Text("SIMPAN SETTING") }

        TextButton(onClick = onBack, modifier = Modifier.fillMaxWidth()) { Text("KEMBALI") }
    }
}

@Composable
private fun SettingNumber(title: String, value: Int, onChange: (Int) -> Unit) {
    OutlinedTextField(
        value = value.toString(),
        onValueChange = { it.toIntOrNull()?.let(onChange) },
        label = { Text(title) }, singleLine = true, modifier = Modifier.fillMaxWidth()
    )
    Spacer(Modifier.height(12.dp))
}

@Composable
private fun MessageBubble(message: ChatMessage) {
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = if (message.fromUser) Arrangement.End else Arrangement.Start
    ) {
        Surface(color = if (message.fromUser) Purple else Panel, shape = RoundedCornerShape(16.dp)) {
            Text(message.text, color = TextMain, modifier = Modifier.padding(13.dp), fontSize = 15.sp)
        }
    }
}

@Composable
private fun GopalTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(background = Bg, surface = Panel, primary = Purple),
        content = content
    )
}
